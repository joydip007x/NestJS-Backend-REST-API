import 'bootstrap';
import bootstrap from  'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter, Route,Routes, Link, Switch} from 'react-router-dom'
import NewView from './newView';
import Dap from './Dap';
import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import Cookies from 'js-cookie';
import NewView2 from './newView2';

function App() {

  axios.defaults.headers.common = {
    'Authorization': 'Bearer ' + Cookies.get('jwt-token')
  };
  
  console.log( axios.defaults.headers.common,"\nC: ",axios.defaults.Cookies);

  return (
    <div className="App">
      
      <BrowserRouter>
       <Routes>
          <Route path="/" element={<Dap />}></Route>
          <Route path="/newView" element={<NewView />}></Route>
          <Route path="/newView2" element={<NewView2 />}></Route>

        </Routes>
      </BrowserRouter>
    </div>
  );
}
export default App;