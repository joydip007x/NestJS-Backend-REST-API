import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Link, Switch } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux';
import React, { useState, useEffect } from 'react'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { loginUID } from './actions/uidlogin';

function Dap() {

  const [email, setEmail] = useState('');
  const [password, setPass] = useState('');
  const [numbers, setNumbers] = useState(0);

  const dispatch = useDispatch()
  const { loadingx, successx, currentBankUser } = useSelector(state => state.loginUIDReducer)
  
  // console.log(currentBankUser)

  function loginWithUID() {

    // if (!password || (email && !email.match(/.+@.+/))) {
    //   return toast.warning('Fill the Details Properly',
    //     { position: toast.POSITION.TOP_CENTER, autoClose: 1800 })
    // }
    const bankuser = { 
      
      "email": email,
      "password": password,
      "numbers": numbers
    }
    console.log(bankuser)

    dispatch(loginUID(bankuser))


  }
   
  function logout() {
    
    localStorage.removeItem('currentBankUser');
    window.location.href = '/'
  }
  // const pp = localStorage.getItem('currentBankUser')
  // console.log(pp + '       x' + currentBankUser);
  
  
  useEffect(
    () => {
      // const bankuser = { email, password }
      // let timer1 = setTimeout(() =>  dispatch(loginUID(bankuser)),  5000);
    
      // return () => {
      //   clearTimeout(timer1);
      // };
    } );
    
  return (
    <div className="Dap">
      <ToastContainer limit={2} />
          <div>
            <form className="login" >
              <h1 style={{ 'fontFamily': 'monospace'}}>Demo-Mode</h1>
              <input type="text" placeholder="Username"
                value={email} onChange={(e) => setEmail(e.target.value)} required
              />
              <input type="password" placeholder="Password"
                value={password} onChange={(e) => setPass(e.target.value)} //required
              />
              <input type="number" placeholder="No"
                value={numbers} onChange={(e) => setNumbers(e.target.value)} //required
              />
              <button type="button" id='log' onClick={loginWithUID} /*onSubmit="return false"*/ >Login</button>
            </form>
          </div>
    </div>
  );
}

export default Dap;
