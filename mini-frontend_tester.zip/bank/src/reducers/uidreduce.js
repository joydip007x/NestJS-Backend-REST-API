
export const loginUIDReducer= (state={},action)=>{

    switch(action.type){

        case 'USER_UID_REQUEST': return {

            loadingx:true,
            successx:false,
        }
        case 'USER_UID_SUCCESS': return {

            loadingx:false,
            successx:true,
            currentBankUser:action.payload
        }
        case 'USER_UID_FAILED': return {

            loadingx:false,
            successx:false,
            error:action.payload
        }
        default : return state;
    }
}

export const loginUIDReducer2= (state={},action)=>{

    switch(action.type){

        case 'USER_UID_REQUEST2': return {

            loadingx2:true,
            successx2:false,
        }
        case 'USER_UID_SUCCESS2': return {

            loadingx2:false,
            successx2:true,
            currentBankUser2:action.payload
        }
        case 'USER_UID_FAILED2': return {

            loadingx2:false,
            successx2:false,
            error:action.payload
        }
        default : return state;
    }
}


export const loginUIDReducer3= (state={},action)=>{

    switch(action.type){

        case 'USER_UID_REQUEST3': return {

            loadingx3:true,
            successx3:false,
        }
        case 'USER_UID_SUCCESS3': return {

            loadingx3:false,
            successx3:true,
            currentBankUser:action.payload
        }
        case 'USER_UID_FAILED3': return {

            loadingx3:false,
            successx3:false,
            error:action.payload
        }
        default : return state;
    }
}

export const loginUIDReducerx= (state={},action)=>{

    switch(action.type){

        case 'USER_UID_REQUESTX2': return {

            loadingx2:true,
            successx2:false,
        }
        case 'USER_UID_SUCCESSX2': return {

            loadingx2:false,
            successx2:true,
            currentBankUserX2:action.payload
        }
        case 'USER_UID_FAILEDX2': return {

            loadingx2:false,
            successx2:false,
            error:action.payload
        }
        default : return state;
    }
}


export const loginUIDReducerx2= (state={},action)=>{

    switch(action.type){

        case 'USER_UID_REQUESTXX3': return {

            loadingx3:true,
            successx3:false,
        }
        case 'USER_UID_SUCCESSXX3': return {

            loadingx3:false,
            successx3:true,
            currentBankUserx3:action.payload
        }
        case 'USER_UID_FAILEDXX3': return {

            loadingx3:false,
            successx3:false,
            error:action.payload
        }
        default : return state;
    }
}
