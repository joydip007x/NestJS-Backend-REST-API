import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { loginUID2, loginUID3 } from './actions/uidlogin';

export default function NewView() {

    const [r1, setR1] = useState('');
    const [r2, setR2] = useState('');
    const [r3, setR3] = useState('Fetching csrf Token...');

    const dispatch = useDispatch()
    const { loadingx2, successx2, currentBankUser2 } = useSelector(state => state.loginUIDReducer2)
    const { loadingx3, successx3, currentBankUser } = useSelector(state => state.loginUIDReducer3)



  //   if( !loadingx && successx ){
  //     console.log(currentBankUser2.session.csrf);
  //      setR3(currentBankUser2.session.csrf)
  //  }

    // eslint-disable-next-line no-unused-vars
    function callNew2(){
      if( !loadingx2 && successx2  ){
           console.log('1 :' + currentBankUser2.session.csrf);
          setR3(currentBankUser2.session.csrf)
        }
    }
    function callNew() {

    setR3(currentBankUser2.session.csrf)
    console.log('loadingx2 : ',loadingx2,' successx2: ',successx2,'\nCsrf : ', currentBankUser2?.session?.csrf);
    const bankuser = { 
         email:r1, csrf:currentBankUser2.session.csrf
    }  
    console.log(bankuser);
    dispatch(loginUID3(bankuser));
    


    // if( !loadingx2 && successx2  ){
    //   console.log('1 :' + currentBankUser2.session.csrf);
    //   setR3(currentBankUser2.session.csrf)
    // }
    // 
   }


  useEffect(() => {
    dispatch(loginUID2());
    //callNew2();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[])

   return (
     <div>
         {/* <h2> New View </h2> */}
              <div className="Dap2">
          <div>
            <form className="login2" >
              <h1 style={{ 'fontFamily': 'monospace'}}>Demo-Session-Token</h1>
              
              <input type="text" placeholder="R1"
                value={r1} onChange={(e) => setR1(e.target.value)} required
              />
              <input type="text" placeholder="R2"
                value={r2} onChange={(e) => {setR2(e.target.value); console.log('R3:',r3);}} //required
              />

             {
              !loadingx2 && successx2 && 
              <input type="text" placeholder="R3"   required //hidden
                value={currentBankUser2.session.csrf} onChange={(e) => setR3(currentBankUser2.session.csrf)}
               // onLoad={setR3(currentBankUser2.session.csrf)}
              />
              }
              <button type="button" id='log' onClick={callNew} /*onSubmit="return false"*/ 
              >Login</button>
            </form>

             {
               !loadingx3 && successx3 &&
               alert(JSON.stringify(currentBankUser))
             }
          </div>
    </div>

     </div>
   )
}