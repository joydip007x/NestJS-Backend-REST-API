import axios from 'axios'


export const loginUID=(user)=>async dispatch=>{

    dispatch({type:'USER_UID_REQUEST'})
    try {
       console.log(user);
       axios.withCredentials = false;
       let f=user.numbers;
       delete user.numbers;
       console.log('F ',f , '  x ',user);
       const response=await axios.post('/auth/signin',user/*, {'withCredentials':false}*/)
       console.log(response.data);
       dispatch({type:'USER_UID_SUCCESS',payload:response.data})
       localStorage.setItem('currentBankUser',JSON.stringify(response.data))

       if(!f)window.location.href='/newView'
       else window.location.href='/newView2'

    //    window.location.href='/userAccounts'
    } catch (error) {
        dispatch({type:'USER_UID_FAILED',payload:error})
    }

}


export const loginUID2=()=>async dispatch=>{

    dispatch({type:'USER_UID_REQUEST2'})
    try {
      
       const response=await axios.get('/users/me')
       console.log(response.data);
       dispatch({type:'USER_UID_SUCCESS2',payload:response.data})
       localStorage.setItem('currentBankUser2',JSON.stringify(response.data))
       //window.location.href='/newView'
    //    window.location.href='/userAccounts'
    } catch (error) {
        dispatch({type:'USER_UID_FAILED2',payload:error})
    }

}

export const loginUID3=(user)=>async dispatch=>{

    dispatch({type:'USER_UID_REQUEST3'})
    try {
       
       console.log('loginUID3:');
       console.log(user);
       const response=await axios.post('/users/me',user);
       console.log(response);
       dispatch({type:'USER_UID_SUCCESS3',payload:response.data})
       localStorage.setItem('currentBankUser3',JSON.stringify(response.data))
       //window.location.href='/newView'
    //    window.location.href='/userAccounts'
    } catch (error) {
        dispatch({type:'USER_UID_FAILED3',payload:error})
    }

}



export const loginUIDx=()=>async dispatch=>{

    dispatch({type:'USER_UID_REQUESTX2'})
    try {
      
       const response=await axios.get('/users/meew')
       console.log(response.data);
       dispatch({type:'USER_UID_SUCCESSX2',payload:response.data})
       localStorage.setItem('NEwcurrentBankUser2',JSON.stringify(response.data))
       //window.location.href='/newView'
    //    window.location.href='/userAccounts'
    } catch (error) {
        dispatch({type:'USER_UID_FAILEDX2',payload:error})
    }

}

export const loginUIDx2=(user)=>async dispatch=>{

    dispatch({type:'USER_UID_REQUESTXX3'})
    try {
       
       console.log('loginUID3:');
       console.log(user);
       const response=await axios.post('/users/meew',user);
       console.log(response);
       dispatch({type:'USER_UID_SUCCESSXX3',payload:response.data})
       localStorage.setItem('NewcurrentBankUser3',JSON.stringify(response.data))
       //window.location.href='/newView'
    //    window.location.href='/userAccounts'
    } catch (error) {
        dispatch({type:'USER_UID_FAILEDXX3',payload:error})
    }

}