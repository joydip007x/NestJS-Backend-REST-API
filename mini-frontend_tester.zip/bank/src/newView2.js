import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { loginUIDx,loginUIDx2 } from './actions/uidlogin';

export default function NewView2() {

    const [r1, setR1] = useState('');
    const [r2, setR2] = useState('');
    const [r3, setR3] = useState('Fetching csrf Token...');

    const dispatch = useDispatch()
    const { loadingx2, successx2, currentBankUserX2 } = useSelector(state => state.loginUIDReducerx)
    const {  loadingx3,successx3,currentBankUserx3  } = useSelector(state => state.loginUIDReducerx2)



  //   if( !loadingx && successx ){
  //     console.log(currentBankUser2.session.csrf);
  //      setR3(currentBankUser2.session.csrf)
  //  }

 
    function callNew() {

    setR3(currentBankUserX2.session.csrf)
    console.log('loadingx2 : ',loadingx2,' successx2: ',successx2,'\nCsrf : ', currentBankUserX2?.session?.csrf);
    const bankuser = { 
         email:r1, csrf:currentBankUserX2.session.csrf
    }  
    console.log(bankuser);
    dispatch(loginUIDx2(bankuser));
    


    // if( !loadingx2 && successx2  ){
    //   console.log('1 :' + currentBankUser2.session.csrf);
    //   setR3(currentBankUser2.session.csrf)
    // }
    // 
   }


  useEffect(() => {
    dispatch(loginUIDx());
    //callNew2();
  },[])

   return (
     <div>
         {/* <h2> New View </h2> */}
              <div className="Dap2">
          <div>
            <form className="login2" >
              <h1 style={{ 'fontFamily': 'monospace'}}>Demo-Session-Token</h1>
              
              <input type="text" placeholder="R1"
                value={r1} onChange={(e) => setR1(e.target.value)} required
              />
              <input type="text" placeholder="R2"
                value={r2} onChange={(e) => {setR2(e.target.value); console.log('R3:',r3);}} //required
              />

             {
              !loadingx2 && successx2 && 
              <input type="text" placeholder="R3"   required //hidden
                value={currentBankUserX2.session.csrf} onChange={(e) => setR3(currentBankUserX2.session.csrf)}
               // onLoad={setR3(currentBankUser2.session.csrf)}
              />
              }
              <button type="button" id='log' onClick={callNew} /*onSubmit="return false"*/ 
              >Login</button>
            </form>

             {
               !loadingx3 && successx3 &&
               alert(JSON.stringify(currentBankUserx3))
             }
          </div>
    </div>

     </div>
   )
}